#!/usr/bin/env python3
from pathlib import Path
import re
import sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else '.')
manifest = root / 'android/app/src/main/AndroidManifest.xml'
if not manifest.exists():
    raise SystemExit(f'Missing {manifest}')
text = manifest.read_text(encoding='utf-8')

app_match = re.search(r'<application\b[^>]*>', text, flags=re.S)
if not app_match:
    raise SystemExit('AndroidManifest.xml has no <application> tag')
app = app_match.group(0)

def set_attr(tag: str, name: str, value: str) -> str:
    pattern = rf'\s{name}="[^"]*"'
    if re.search(pattern, tag):
        return re.sub(pattern, f' {name}="{value}"', tag)
    return tag[:-1] + f' {name}="{value}">'

app = set_attr(app, 'android:label', 'PRÍDEL')
app = set_attr(app, 'android:allowBackup', 'false')
app = set_attr(app, 'android:usesCleartextTraffic', 'false')
text = text[:app_match.start()] + app + text[app_match.end():]
manifest.write_text(text, encoding='utf-8')

# Hard verification. The build must fail rather than silently ship wrong settings.
check = manifest.read_text(encoding='utf-8')
required = [
    'android:label="PRÍDEL"',
    'android:allowBackup="false"',
    'android:usesCleartextTraffic="false"',
]
missing = [item for item in required if item not in check]
if missing:
    raise SystemExit('Manifest verification failed: ' + ', '.join(missing))
print('Android manifest configured and verified.')
