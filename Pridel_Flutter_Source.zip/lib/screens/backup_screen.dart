import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../controllers/app_controller.dart';

class BackupScreen extends StatefulWidget {
  const BackupScreen({super.key, required this.controller});
  final AppController controller;

  @override
  State<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen> {
  final importController = TextEditingController();
  bool busy = false;

  @override
  void dispose() {
    importController.dispose();
    super.dispose();
  }

  Future<void> _copyBackup() async {
    setState(() => busy = true);
    try {
      final data = await widget.controller.database.exportBackupJson();
      await Clipboard.setData(ClipboardData(text: data));
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Záloha je skopírovaná do schránky. Ulož ju na bezpečné miesto.')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _paste() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (data?.text != null) importController.text = data!.text!;
  }

  Future<void> _restore() async {
    if (importController.text.trim().isEmpty || busy) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Obnoviť zálohu?'),
        content: const Text('Aktuálne lokálne údaje sa nahradia obsahom zálohy. Vstavané recepty zostanú zachované.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Zrušiť')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Obnoviť')),
        ],
      ),
    );
    if (ok != true) return;
    setState(() => busy = true);
    try {
      await widget.controller.database.importBackupJson(importController.text.trim());
      widget.controller.dataChanged();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Záloha bola obnovená.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Obnova zlyhala: $e')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Záloha a obnova')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Card(child: ListTile(leading: Icon(Icons.shield_outlined), title: Text('Záloha obsahuje tvoje lokálne dáta'), subtitle: Text('Domácnosť, zásoby, jedálniček, históriu, zvyšky, vlastné recepty, ceny a nastavenia.'))),
            const SizedBox(height: 14),
            SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: busy ? null : _copyBackup, icon: const Icon(Icons.copy_all_outlined), label: const Text('Skopírovať kompletnú zálohu'))),
            const SizedBox(height: 28),
            Text('Obnova', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 8),
            const Text('Vlož text zálohy PRÍDEL. Pred obnovou sa kontroluje typ a verzia zálohy.'),
            const SizedBox(height: 12),
            TextField(controller: importController, minLines: 5, maxLines: 10, decoration: const InputDecoration(hintText: '{ "app": "PRIDEL", ... }')),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: OutlinedButton.icon(onPressed: _paste, icon: const Icon(Icons.content_paste), label: const Text('Vložiť zo schránky'))),
              const SizedBox(width: 10),
              Expanded(child: FilledButton(onPressed: busy ? null : _restore, child: const Text('Obnoviť'))),
            ]),
          ],
        ),
      );
}
