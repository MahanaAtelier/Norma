import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'package:pridel/app.dart';
import 'package:pridel/controllers/app_controller.dart';
import 'package:pridel/data/app_database.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();

  testWidgets('app starts and shows onboarding on a fresh database', (tester) async {
    final dir = await Directory.systemTemp.createTemp('pridel_smoke_');
    final db = AppDatabase(
      factory: databaseFactoryFfi,
      databasePathProvider: () async => dir.path,
    );
    await db.initialize();
    addTearDown(() async {
      await db.close();
      await dir.delete(recursive: true);
    });

    await tester.pumpWidget(PridelApp(controller: AppController(db)));
    await tester.pumpAndSettle();

    expect(find.text('PRÍDEL'), findsOneWidget);
    expect(find.text('Menej rozmýšľania, čo variť'), findsOneWidget);
  });
}
