import 'package:flutter_test/flutter_test.dart';

import 'package:pridel/app.dart';
import 'package:pridel/controllers/app_controller.dart';
import 'package:pridel/data/app_database.dart';

class _SmokeDatabase extends AppDatabase {
  @override
  Future<bool> getOnboardingComplete() async => false;
}

void main() {
  testWidgets('app starts and shows onboarding on a fresh profile', (tester) async {
    // Widget smoke test intentionally uses a tiny fake database boundary.
    // Real SQLite initialization, schema integrity and backup round-trip are
    // covered separately in database_test.dart. Keeping real FFI I/O out of
    // the widget test prevents FakeAsync from waiting forever on isolate I/O.
    final controller = AppController(_SmokeDatabase());

    await tester.pumpWidget(PridelApp(controller: controller));
    await tester.pump();

    expect(find.text('PRÍDEL'), findsOneWidget);
    expect(find.text('Menej rozmýšľania, čo variť'), findsOneWidget);
    expect(find.text('Pokračovať'), findsOneWidget);
  });
}
