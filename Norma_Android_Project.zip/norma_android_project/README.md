# Norma – Android

Offline-first Android beta rodinného plánovača jedál.

## Čo je v tejto verzii
- týždenný a 4-týždňový plán
- recepty, nákup, zásoby a rodina
- alergie a „NEJEM“
- kuchynské dávky a plánované zvyšky
- energia na 1 porciu
- celá / polovičná porcia
- svetlý a tmavý režim
- lokálna záloha a obnova cez Android výber súborov
- tlač cez Android Print

Aplikácia je offline. Dáta sa ukladajú lokálne v úložisku WebView aplikácie.

## APK
GitHub Actions workflow `Build Android APK` zostaví testovacie APK pri každom pushi na `main` a uloží ho ako artifact `Norma-Android-APK`.

> Toto je testovacia debug verzia. Pred verejnou distribúciou treba nastaviť release signing a finálne úložisko/migrácie dát.
